export { default } from './ScreenClaimModal';
