export { default } from './MediaTable.js';
