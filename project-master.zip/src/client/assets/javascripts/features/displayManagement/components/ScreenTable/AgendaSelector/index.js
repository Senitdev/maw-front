export { default } from './AgendaSelector';
