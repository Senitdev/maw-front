export { default } from './AgendaTableContainer';
