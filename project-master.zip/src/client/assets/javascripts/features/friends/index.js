// Feature/Module index is responsible for maintaining its public API
// This is the exposed surface where modules can interface with each other.

export {
  default,
  actionCreators,
  selector,
  NAME
} from './friends';
