export { default } from './AddFriendInput';
