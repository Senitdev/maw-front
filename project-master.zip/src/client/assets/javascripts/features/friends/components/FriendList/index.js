export { default } from './FriendList';
