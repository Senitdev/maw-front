export {
  default,
  actionCreators,
  selector,
  NAME
} from './auth';
