export type State = {
  collapsedSideMenu: boolean,
};
